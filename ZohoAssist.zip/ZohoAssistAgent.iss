[InstallShield Silent]
Version=v7.00
File=Response File
[File Transfer]
OverwrittenReadOnly=NoToAll
[{95F1F02B-F4AB-4851-A5BF-ADDD20AA2D58}-DlgOrder]
Count=0
